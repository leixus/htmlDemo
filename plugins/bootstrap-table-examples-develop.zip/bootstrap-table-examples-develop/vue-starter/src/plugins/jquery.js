import jQuery from 'jquery'
window.jQuery = jQuery
